package com.iandwe.alarm.fcm.constant;

public class FCMMessage {

    public static final String FCM_TITLE_MESSAGE = "님, ";

    public static final String FCM_ESSENTIAL_MESSAGE = " 받으실 기간입니다.";

    public static final String FCM_BODY_MESSAGE = "아이와 산모를 위해 늦지않게 받아주세요 !";

}
