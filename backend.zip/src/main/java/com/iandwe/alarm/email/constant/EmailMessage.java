package com.iandwe.alarm.email.constant;

public class EmailMessage {

    public static final String EMAIL_START_MESSAGE = "님, 안녕하세요 ! \n";

    public static final String EMAIL_PERIOD = "기간입니다. \n";

    public static final String EMAIL_LAST_MESSAGE = "늦지않게 받아주세요. \n 오늘도 행복한 하루 되시길 바랍니다 !";

}
