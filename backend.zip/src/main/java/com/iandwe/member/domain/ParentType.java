package com.iandwe.member.domain;

public enum ParentType {
    MOTHER, FATHER
}
