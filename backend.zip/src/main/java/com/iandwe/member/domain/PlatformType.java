package com.iandwe.member.domain;

public enum PlatformType {
    NONE, KAKAO, NAVER, GOOGLE
}
