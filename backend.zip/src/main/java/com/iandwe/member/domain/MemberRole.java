package com.iandwe.member.domain;

public enum MemberRole {
    USER, ADMIN
}
